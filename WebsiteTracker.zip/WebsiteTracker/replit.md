# SportsIN Platform

## Overview

SportsIN is a next-generation career platform designed specifically for Indian athletes, brands, and organizations. It serves as a comprehensive ecosystem connecting athletes with career opportunities, NIL deals, and professional networking. The platform goes beyond traditional job boards by integrating sports-specific features, matchmaking algorithms, and a focus on the Indian sports market.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript
- **Build Tool**: Vite for development and bundling
- **UI Library**: Radix UI components with shadcn/ui design system
- **Styling**: Tailwind CSS with custom sports-themed design tokens
- **State Management**: React Query for server state, React Context for authentication
- **Routing**: Wouter for lightweight client-side routing
- **Theme Support**: next-themes for dark/light mode switching

### Backend Architecture
- **Runtime**: Node.js with Express.js server
- **Language**: TypeScript throughout the stack
- **Database**: Firebase Firestore (NoSQL document database)
- **Authentication**: Firebase Auth with multiple providers (Google, Facebook, Apple, phone, email)
- **File Storage**: Firebase Storage for document and media uploads
- **Real-time Features**: WebSocket support for live updates

### Data Storage Solutions
- **Primary Database**: Firebase Firestore with role-based security rules
- **File Storage**: Firebase Storage for resumes, profile pictures, and documents
- **Database Structure**:
  - `/users/{uid}` - User profiles and authentication data
  - `/athleteProfiles/{id}` - Detailed athlete information and stats
  - `/jobs/{id}` - Job listings from employers and brands
  - `/nilOpportunities/{id}` - NIL (Name, Image, Likeness) deals
  - `/jobApplications/{id}` - Application submissions and tracking
- **Backup Strategy**: In-memory storage class for development/testing

### Authentication and Authorization
- **Provider**: Firebase Authentication
- **Supported Methods**: 
  - Social login (Google, Facebook, Apple)
  - Email/password authentication
  - Phone number verification
  - Anonymous demo accounts
- **Role-based Access**: User roles include athlete, brand, coach, scout, admin, manager
- **Security**: Firestore security rules enforce data access based on user roles
- **Session Management**: Firebase handles token management and renewal

### External Service Integrations
- **Firebase Services**: Authentication, Firestore, Storage, App Check
- **Payment Processing**: Razorpay integration for NIL deals and micro-sponsorships
- **File Processing**: Support for resume uploads (PDF, DOC, DOCX)
- **Social Media**: Profile integration with Instagram, Twitter, YouTube
- **Future Integrations**: Wearable data (Apple Health, Garmin, Google Fit), AI video processing

## Key Components

### Core User Types
1. **Athletes**: Create profiles, apply for jobs, showcase achievements, access NIL deals
2. **Brands/Employers**: Post job opportunities, scout talent, manage applications
3. **Coaches**: Talent development, mentoring, recommendation systems
4. **Scouts**: Talent discovery, evaluation, networking
5. **Administrators**: Platform management, analytics, content moderation

### Feature Modules
1. **Dashboard System**: Role-based dashboards with personalized content
2. **Job Board**: Advanced filtering, matching algorithms, application tracking
3. **NIL Marketplace**: Brand partnership opportunities, compensation tracking
4. **Profile Management**: Comprehensive athlete profiles with stats and achievements
5. **Application System**: Multi-step forms with document upload and auto-save
6. **Onboarding Flow**: Role-specific guided setup process
7. **Matchmaking Engine**: AI-powered job matching based on skills, location, and preferences

## Data Flow

### User Registration and Onboarding
1. User selects authentication method (social, email, phone, demo)
2. Firebase Auth creates user account and returns authentication token
3. User document created in Firestore with basic profile information
4. Role-based onboarding flow guides user through profile completion
5. Specialized profile documents created based on user role (e.g., athleteProfile for athletes)

### Job Application Process
1. User browses job board with real-time filtering and matching scores
2. Multi-step application form with auto-save functionality
3. Document upload to Firebase Storage with progress tracking
4. Application data stored in Firestore with job and user references
5. Real-time notifications to employers about new applications
6. Application status tracking and communication system

### Content Management
1. Job postings created by verified employers with approval workflow
2. NIL opportunities managed by brands with compensation structures
3. User-generated content (profiles, achievements) with moderation capabilities
4. Analytics and reporting for platform administrators

## External Dependencies

### Core Dependencies
- **Firebase SDK**: Authentication, Firestore, Storage services
- **React Ecosystem**: React 18+, React Query, React Hook Form
- **UI Components**: Radix UI primitives, Lucide React icons
- **Styling**: Tailwind CSS, class-variance-authority, clsx
- **Form Handling**: React Hook Form with Zod validation
- **Date Handling**: date-fns for formatting and manipulation

### Development Dependencies
- **TypeScript**: Type safety across frontend and backend
- **Vite**: Fast development server and optimized production builds
- **ESBuild**: Backend bundling for production deployment
- **PostCSS**: CSS processing with Tailwind and Autoprefixer

### Third-party Services
- **Neon Database**: PostgreSQL option configured with Drizzle ORM
- **Replit Integration**: Development environment optimization
- **Analytics**: Built-in admin dashboard for platform metrics

## Deployment Strategy

### Development Environment
- **Local Development**: Vite dev server with Express API proxy
- **Hot Module Replacement**: Fast development iteration with HMR
- **Environment Variables**: Firebase configuration through environment variables
- **Database**: Firebase emulators for local development

### Production Deployment
- **Build Process**: 
  1. Frontend built with Vite to `dist/public`
  2. Backend bundled with ESBuild to `dist/index.js`
- **Hosting Options**: 
  - Firebase Hosting (recommended for Firebase integration)
  - Vercel/Netlify for static frontend with serverless functions
  - Traditional VPS/cloud deployment
- **Database**: Firebase Firestore in production mode with security rules
- **CDN**: Firebase Storage serves files through global CDN
- **Monitoring**: Firebase Analytics and custom admin dashboard

### Scalability Considerations
- **Database**: Firestore scales automatically with usage
- **File Storage**: Firebase Storage handles global file distribution
- **Authentication**: Firebase Auth scales to millions of users
- **Real-time Features**: WebSocket server can be scaled horizontally
- **Caching Strategy**: React Query provides client-side caching, Firestore offline support

The architecture prioritizes rapid development and scalability while maintaining a sports-focused user experience tailored for the Indian market. The Firebase ecosystem provides reliable infrastructure, while the React frontend offers a modern, responsive user interface.