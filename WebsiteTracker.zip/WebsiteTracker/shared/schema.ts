import { z } from "zod";

// User Schema
export const userSchema = z.object({
  id: z.string(),
  email: z.string().email(),
  name: z.string(),
  role: z.enum(['athlete', 'brand', 'coach', 'scout', 'admin', 'manager']),
  profilePicUrl: z.string().optional(),
  createdAt: z.date(),
  onboardingComplete: z.boolean().default(false),
  verified: z.boolean().default(false),
  city: z.string().optional(),
  state: z.string().optional(),
  phoneNumber: z.string().optional(),
  bio: z.string().optional(),
});

export const insertUserSchema = userSchema.omit({ id: true, createdAt: true });

export type User = z.infer<typeof userSchema>;
export type InsertUser = z.infer<typeof insertUserSchema>;

// Athlete Profile Schema
export const athleteProfileSchema = z.object({
  id: z.string(),
  userId: z.string(),
  sport: z.string(),
  position: z.string().optional(),
  achievements: z.array(z.string()).default([]),
  stats: z.record(z.string(), z.union([z.string(), z.number()])).default({}),
  education: z.array(z.object({
    institution: z.string(),
    degree: z.string(),
    year: z.number(),
  })).default([]),
  experience: z.array(z.object({
    team: z.string(),
    position: z.string(),
    duration: z.string(),
    achievements: z.string().optional(),
  })).default([]),
  socialMedia: z.object({
    instagram: z.string().optional(),
    twitter: z.string().optional(),
    youtube: z.string().optional(),
  }).optional(),
  nilEarnings: z.number().default(0),
  followers: z.number().default(0),
  highlights: z.array(z.string()).default([]),
});

export const insertAthleteProfileSchema = athleteProfileSchema.omit({ id: true });

export type AthleteProfile = z.infer<typeof athleteProfileSchema>;
export type InsertAthleteProfile = z.infer<typeof insertAthleteProfileSchema>;

// Job Schema
export const jobSchema = z.object({
  id: z.string(),
  title: z.string(),
  company: z.string(),
  description: z.string(),
  requirements: z.array(z.string()).default([]),
  location: z.string(),
  city: z.string(),
  state: z.string(),
  salary: z.string(),
  employmentType: z.enum(['full-time', 'part-time', 'contract', 'internship']),
  sport: z.string().optional(),
  experienceLevel: z.enum(['entry', 'mid', 'senior', 'executive']),
  postedBy: z.string(),
  createdAt: z.date(),
  applicationDeadline: z.date(),
  isActive: z.boolean().default(true),
  applicantCount: z.number().default(0),
  sector: z.enum(['private', 'public', 'government', 'ngo']).optional(),
});

export const insertJobSchema = jobSchema.omit({ id: true, createdAt: true, applicantCount: true });

export type Job = z.infer<typeof jobSchema>;
export type InsertJob = z.infer<typeof insertJobSchema>;

// Job Application Schema
export const jobApplicationSchema = z.object({
  id: z.string(),
  jobId: z.string(),
  applicantId: z.string(),
  status: z.enum(['pending', 'reviewed', 'shortlisted', 'rejected', 'hired']).default('pending'),
  resumeUrl: z.string().optional(),
  coverLetterUrl: z.string().optional(),
  customAnswers: z.record(z.string(), z.string()).default({}),
  appliedAt: z.date(),
  lastUpdated: z.date(),
  matchPercentage: z.number().optional(),
});

export const insertJobApplicationSchema = jobApplicationSchema.omit({ 
  id: true, 
  appliedAt: true, 
  lastUpdated: true 
});

export type JobApplication = z.infer<typeof jobApplicationSchema>;
export type InsertJobApplication = z.infer<typeof insertJobApplicationSchema>;

// NIL Opportunity Schema
export const nilOpportunitySchema = z.object({
  id: z.string(),
  title: z.string(),
  brandName: z.string(),
  description: z.string(),
  compensation: z.string(),
  requirements: z.array(z.string()).default([]),
  sport: z.string().optional(),
  minFollowers: z.number().default(0),
  platforms: z.array(z.string()).default([]),
  duration: z.string(),
  createdBy: z.string(),
  createdAt: z.date(),
  deadline: z.date(),
  isActive: z.boolean().default(true),
  applicantCount: z.number().default(0),
  category: z.enum(['product', 'service', 'event', 'brand-ambassador']),
});

export const insertNILOpportunitySchema = nilOpportunitySchema.omit({ 
  id: true, 
  createdAt: true, 
  applicantCount: true 
});

export type NILOpportunity = z.infer<typeof nilOpportunitySchema>;
export type InsertNILOpportunity = z.infer<typeof insertNILOpportunitySchema>;

// NIL Application Schema
export const nilApplicationSchema = z.object({
  id: z.string(),
  opportunityId: z.string(),
  athleteId: z.string(),
  status: z.enum(['pending', 'approved', 'rejected', 'completed']).default('pending'),
  proposal: z.string(),
  expectedDelivery: z.date(),
  appliedAt: z.date(),
  lastUpdated: z.date(),
});

export const insertNILApplicationSchema = nilApplicationSchema.omit({ 
  id: true, 
  appliedAt: true, 
  lastUpdated: true 
});

export type NILApplication = z.infer<typeof nilApplicationSchema>;
export type InsertNILApplication = z.infer<typeof insertNILApplicationSchema>;
